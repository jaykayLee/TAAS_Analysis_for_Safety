# 플랫폼 기반 배달 이륜차 교통사고 영향요인 분석 (Analysis on Factors Contributing to Motorcycle Accidents of Food Delivery Riders)

- 주제: 자동차
- 저자: 이상준·박준태
- 학술지·발행: 한국안전학회지 37(1) (2022)
- 자료·기간: 배달 라이더 554명 설문, 2020-11
- 방법: 포아송 회귀, CHAID
- 핵심 결과: 경력 1년 미만 연 약 2.3건 vs 4년 이상 약 1.2건. 운행 중 콜 수락·강제 배정·다중 플랫폼이 사고 증가 요인
- 이 프로젝트와의 연결: 9202 이륜차 신고대수·이륜 사고 — 노출(배달량) 변수 필요성
- 원문 공개: 공개(KoreaScience)
- 링크: https://koreascience.kr/article/JAKO202213841426196.pdf
- 공개 PDF: https://koreascience.kr/article/JAKO202213841426196.pdf
- 확인: 원문 확인
