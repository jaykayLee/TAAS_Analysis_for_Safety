# Predicting road casualties in Flanders in relation to an ageing population: combining decomposition and disaggregation

- 주제: 출생률·인구
- 저자: Van Hout K, Brijs T, Daniels S, Hermans E, Wets G
- 학술지·발행: Hasselt Univ. IMOB 원고(TRB 제출) (2012)
- 자료·기간: 벨기에 플랑드르 인구 표본·통행조사·사상자 1997~2009, 전망 2010~2020
- 방법: 노출(인구×통행거리)·위험 분해, 로짓 가중치 갱신
- 핵심 결과: 위험이 그대로면 고령화로 사상자 약 +8%, 실제 전망은 위험 감소로 −57%. 고령 여성 비중 약 2배
- 이 프로젝트와의 연결: 율 분해 기법, 9101 연령별 인구·장래추계 라이브러리
- 원문 공개: 공개(원고)
- 링크: https://documentserver.uhasselt.be/bitstream/1942/15173/1/vanhoutTRB%20paper.pdf
- 공개 PDF: https://documentserver.uhasselt.be/bitstream/1942/15173/1/vanhoutTRB%20paper.pdf
- 확인: 원문 확인
