# Effect of Lowering the Blood Alcohol Concentration Limit to 0.03 Among Hospitalized Trauma Patients in Southern Taiwan: A Cross-Sectional Analysis

- 주제: 교통
- 저자: Huang CY, Chou SE, Su WT, et al.
- 학술지·발행: Risk Management and Healthcare Policy 13:571–581 doi:10.2147/RMHP.S250734 (2020)
- 자료·기간: 대만 외상센터, 2013 기준 강화 전후 각 2년
- 방법: 교차분석·오즈비
- 핵심 결과: 음주 외상환자 12.4%→7.1%, 입원 비용 약 40% 감소 (대만 사례 — 한국 2019 0.03% 비교 근거)
- 이 프로젝트와의 연결: 7159 음주·⑤ 중단 시계열 2019
- 원문 공개: 공개(CC BY-NC)
- 링크: https://pmc.ncbi.nlm.nih.gov/articles/PMC7305841
- 공개 PDF: https://pmc.ncbi.nlm.nih.gov/articles/PMC7305841/pdf/rmhp-13-571.pdf
- 확인: 원문 확인
