# Changes in incidence and severity of commercial motorcycle accidents due to the use of delivery service platforms in Korea: a retrospective cohort study

- 주제: 자동차
- 저자: Moon D, Jang JH, Cho JS, et al.
- 학술지·발행: Journal of Trauma and Injury 36(2) (2023)
- 자료·기간: EDIIS 응급실 8,123명 2011~2020
- 방법: 다변량 로지스틱(EMR-ISS 중증도)
- 핵심 결과: 2016~2020 사고가 2011~2015보다 중증 OR 1.49, 중환자실·사망 OR 2.59
- 이 프로젝트와의 연결: 이륜 사고 심각도(사망/사고 비)
- 원문 공개: 공개(KoreaScience)
- 링크: https://koreascience.kr/article/JAKO202321961157934.pdf
- 공개 PDF: https://koreascience.kr/article/JAKO202321961157934.pdf
- 확인: 원문 확인
