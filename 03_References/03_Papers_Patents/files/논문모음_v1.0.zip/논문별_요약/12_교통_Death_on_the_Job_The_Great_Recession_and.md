# Death on the Job: The Great Recession and Work-Related Traffic Fatalities

- 주제: 교통
- 저자: French MT, Gumus G
- 학술지·발행: IZA Discussion Paper 14324 (2021)
- 자료·기간: 미국 FARS 주×분기 2004~2012
- 방법: 고정효과 회귀
- 핵심 결과: 실업률 1%p↑ → 업무 관련 사망 −4.7%, 전체 −2.9%, 음주 관련 −3.6%
- 이 프로젝트와의 연결: 사업용(7040 차량용도)·경기 변수
- 원문 공개: 공개(PDF)
- 링크: https://docs.iza.org/dp14324.pdf
- 공개 PDF: https://docs.iza.org/dp14324.pdf
- 확인: 원문 확인
