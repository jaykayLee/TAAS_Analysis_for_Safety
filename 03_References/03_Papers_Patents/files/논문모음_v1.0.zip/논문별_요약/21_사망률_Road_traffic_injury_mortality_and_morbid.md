# Road traffic injury mortality and morbidity by country development status, 2011-2017

- 주제: 사망률
- 저자: He JY, Xiao WX, Schwebel DC, et al.
- 학술지·발행: Chinese Journal of Traumatology 24(2):88–93 doi:10.1016/j.cjtee.2021.01.007 (2021)
- 자료·기간: GBD 2017 + WHO 보고, 2011~2017
- 방법: 조인포인트(AAPC)
- 핵심 결과: 모든 SDI 집단에서 연령보정 사망률 감소(고-중 SDI −2.7%/년 최대)
- 이 프로젝트와의 연결: 조인포인트 기법
- 원문 공개: 공개(CC BY-NC-ND)
- 링크: https://pmc.ncbi.nlm.nih.gov/articles/PMC8071733
- 공개 PDF: https://pmc.ncbi.nlm.nih.gov/articles/PMC8071733/pdf/main.pdf
- 확인: 원문 확인
