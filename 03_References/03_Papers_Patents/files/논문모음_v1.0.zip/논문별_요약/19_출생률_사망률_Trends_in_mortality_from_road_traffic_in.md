# Trends in mortality from road traffic injuries in South Korea, 1983-2017: Joinpoint regression and age-period-cohort analyses

- 주제: 출생률·사망률
- 저자: Eun SJ
- 학술지·발행: Accident Analysis & Prevention 134:105325 doi:10.1016/j.aap.2019.105325 (2020)
- 자료·기간: 사망신고·센서스 추계인구 1983~2017
- 방법: 조인포인트, APC(내재추정)
- 핵심 결과: J자형 연령 효과(65세 이상 급증), 1938~1943 출생 코호트 정점 후 감소, 1978~1983 출생 세대 위험 상대적으로 높음
- 이 프로젝트와의 연결: 7344 연령별·APC 기법·사망원인 라이브러리
- 원문 공개: 유료(학술지)
- 링크: http://www.ncbi.nlm.nih.gov/pubmed/31706185
- 공개 PDF: 없음(유료 또는 서지만)
- 확인: 초록 확인
