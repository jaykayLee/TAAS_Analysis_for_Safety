# Global, Regional, and National Burden of Road Injuries from 1990 to 2019

- 주제: 사망률
- 저자: Xu Y, Chen M, Yang R, et al.
- 학술지·발행: IJERPH 19(24):16479 doi:10.3390/ijerph192416479 (2022)
- 자료·기간: GBD 2019, 1990~2019
- 방법: 연령표준화율, EAPC
- 핵심 결과: 세계 연령표준화 사망률 21.92→14.99/10만(EAPC −1.29), 발생은 63.3% 증가
- 이 프로젝트와의 연결: 6809~ OECD 장표·국제 라이브러리
- 원문 공개: 공개(CC BY)
- 링크: https://mdpi.com/1660-4601/19/24/16479
- 공개 PDF: https://www.mdpi.com/1660-4601/19/24/16479/pdf
- 확인: 원문 확인
