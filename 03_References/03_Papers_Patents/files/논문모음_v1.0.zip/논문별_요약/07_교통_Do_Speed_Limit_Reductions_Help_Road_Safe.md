# Do Speed Limit Reductions Help Road Safety? Lessons from the Republic of Korea's Recent Move to Lower Speed Limit on Urban Roads

- 주제: 교통
- 저자: Mitra S, Job S, Han S, Eom K
- 학술지·발행: World Bank GRSF · 한국교통연구원 (2021)
- 자료·기간: 대구 사고 2013~2018(전후 3년), 울산 통행시간 측정
- 방법: 비교군 전후 비교(Hauer)
- 핵심 결과: 총사고 −4.2%, 사망 −15.2%, 보행자 사망 −30.4%(3년 6명). 통행시간 영향 작음. 실제 속도 자료 없음
- 이 프로젝트와의 연결: ⑤ 중단 시계열 2021, 9306 카메라
- 원문 공개: 공개(PDF)
- 링크: https://www.globalroadsafetyfacility.org/sites/default/files/2023-10/Do-Speed-Limit-Reductions-Help-Road-Safety-Lessons-from-the-Republic-of-Koreas-Recent-Move-to-Lower-Speed-Limit-on-Urban-Roads.pdf
- 공개 PDF: https://www.globalroadsafetyfacility.org/sites/default/files/2023-10/Do-Speed-Limit-Reductions-Help-Road-Safety-Lessons-from-the-Republic-of-Koreas-Recent-Move-to-Lower-Speed-Limit-on-Urban-Roads.pdf
- 확인: 원문 확인
