# Pregnancy and the risk of a traffic crash

- 주제: 출생률·인구
- 저자: Redelmeier DA, May SC, Thiruchelvam D, Barrett JFR
- 학술지·발행: CMAJ 186(10) doi:10.1503/cmaj.131650 (2014)
- 자료·기간: 캐나다 온타리오 출산 여성 (임신 전·중·후 비교)
- 방법: 자기 대조 설계
- 핵심 결과: 임신 2분기 중대 사고 위험 증가 보고 — 수치는 원문 확인 필요
- 이 프로젝트와의 연결: 출생률 주제와 교통안전의 연결 고리(직접 자료는 없음)
- 원문 공개: 공개(CMAJ)
- 링크: https://www.cmaj.ca/content/186/10/733
- 공개 PDF: 없음(유료 또는 서지만)
- 확인: 검색 결과로 서지 확인(수치 미확인)
