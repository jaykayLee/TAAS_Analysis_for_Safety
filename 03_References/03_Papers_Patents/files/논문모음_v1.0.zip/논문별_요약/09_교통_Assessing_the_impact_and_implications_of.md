# Assessing the impact and implications of the revised Act on the Aggravated Punishment of Specific Crimes in preventing child traffic injuries in school zones in Korea: an interrupted time series analysis

- 주제: 교통
- 저자: (저자 표기 원문 확인 필요)
- 학술지·발행: Epidemiology and Health 46 (2024)
- 자료·기간: TAAS 2017~2022 (월)
- 방법: 중단 시계열
- 핵심 결과: 보호구역 중상 월 11→8건(p=0.017), 어린이 전체 부상 위험비 0.987(95% CI 0.977–0.997)
- 이 프로젝트와의 연결: 7196·7207 어린이·보호구역 — 같은 TAAS 자료로 재현 가능
- 원문 공개: 공개(PMC11099565)
- 링크: https://www.ncbi.nlm.nih.gov/pmc/articles/PMC11099565/
- 공개 PDF: 없음(유료 또는 서지만)
- 확인: 서지·결과 확인(저자 미확인)
