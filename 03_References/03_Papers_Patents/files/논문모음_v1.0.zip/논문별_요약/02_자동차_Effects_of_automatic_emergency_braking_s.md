# Effects of automatic emergency braking systems on pedestrian crash risk

- 주제: 자동차
- 저자: Cicchino JB
- 학술지·발행: Accident Analysis & Prevention (2022)
- 자료·기간: 미국 경찰 보고 사고 (보험 차량-연)
- 방법: 포아송 회귀 + 준유도 노출(로지스틱)
- 핵심 결과: 보행자 사고 위험 −25~27%, 보행자 부상 사고 −29~30%. 가로등 없는 야간·제한속도 50mph 이상·회전 중에는 효과 근거 없음
- 이 프로젝트와의 연결: 보행자 사고(7285)·야간 — 국내 야간 보행 사고에 기술 한계 시사
- 원문 공개: 유료(학술지)
- 링크: https://iihs.org/topics/bibliography/ref/2243
- 공개 PDF: 없음(유료 또는 서지만)
- 확인: IIHS 서지 페이지 확인
