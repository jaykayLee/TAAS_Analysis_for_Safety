# Effectiveness of forward collision warning and autonomous emergency braking systems in reducing front-to-rear crash rates

- 주제: 자동차
- 저자: Cicchino JB
- 학술지·발행: Accident Analysis & Prevention (2017)
- 자료·기간: 미국 22개 주 경찰 보고 사고, 2010~2014 (보험 차량-연)
- 방법: 포아송 회귀(같은 모델의 장착/미장착 비교)
- 핵심 결과: 추돌(가해) 사고율: FCW 단독 −27%, 저속 AEB −43%, FCW+AEB −50%. 부상 추돌 −20%/−45%/−56%
- 이 프로젝트와의 연결: 차량기술 매핑 탭(AEB), 7002 사고유형(추돌)
- 원문 공개: 유료(학술지)
- 링크: https://www.iihs.org/research-areas/bibliography/ref/2111
- 공개 PDF: 없음(유료 또는 서지만)
- 확인: IIHS 서지 페이지 확인
