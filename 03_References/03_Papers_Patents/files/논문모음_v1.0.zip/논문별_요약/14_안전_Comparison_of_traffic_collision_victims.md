# Comparison of traffic collision victims between older and younger drivers in South Korea: Epidemiologic characteristics, risk factors and types of collisions

- 주제: 안전
- 저자: Ahn JY, Ryoo HW, Park JB, et al.
- 학술지·발행: PLoS ONE 14(4):e0214205 doi:10.1371/journal.pone.0214205 (2019)
- 자료·기간: EDIIS 응급실 운전자 37,511명 2011~2015
- 방법: 포아송·선형 회귀, CMH·카이제곱
- 핵심 결과: 부상 운전자 중 고령 비중 5.0%→8.4%, 단독사고 25.9% vs 20.3%, 안전띠 79.0% vs 83.0%, 병원 내 사망 1.8% vs 0.7%
- 이 프로젝트와의 연결: 7266 노인운전자·7269 사고유형
- 원문 공개: 공개(CC BY)
- 링크: https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6456194/
- 공개 PDF: https://pmc.ncbi.nlm.nih.gov/articles/PMC6456194/pdf/pone.0214205.pdf
- 확인: 원문 확인
