# Impact of lowering the maximum speed limit of city roads on pedestrian traffic accident patients: A nationwide before-and-after study

- 주제: 교통
- 저자: Lee HG, Kim JH
- 학술지·발행: PLoS ONE doi:10.1371/journal.pone.0325320 (2025)
- 자료·기간: 전국 보행자 사고 환자, 5030(2021-04-17) 전후
- 방법: 전국 전후 비교
- 핵심 결과: 수치는 원문 확인 필요(초록 일부만 확인)
- 이 프로젝트와의 연결: 보행자 사고(7285)·⑤ 중단 시계열 2021
- 원문 공개: 공개(CC BY, PMC12157059)
- 링크: https://www.ncbi.nlm.nih.gov/pmc/articles/PMC12157059/
- 공개 PDF: https://doi.org/10.1371/journal.pone.0325320
- 확인: 서지 확인(수치 미확인)
