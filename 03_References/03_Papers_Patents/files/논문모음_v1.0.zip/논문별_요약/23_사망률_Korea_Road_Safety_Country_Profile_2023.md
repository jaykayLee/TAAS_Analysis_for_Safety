# Korea: Road Safety Country Profile 2023

- 주제: 사망률
- 저자: ITF-OECD (IRTAD)
- 학술지·발행: ITF 국가 프로필 (2023)
- 자료·기간: 한국 2012~2022
- 방법: 기술 통계
- 핵심 결과: 2022 사망 2,735명(2012 대비 −49.3%), 인구 10만 명당 5.3명, 보행자 35%·이륜 25%, 75세 이상 사망률 일반의 약 4배
- 이 프로젝트와의 연결: 1 주요 교통지표·OECD 장표 검증
- 원문 공개: 공개(PDF)
- 링크: https://www.itf-oecd.org/sites/default/files/korea-road-safety.pdf
- 공개 PDF: https://www.itf-oecd.org/sites/default/files/korea-road-safety.pdf
- 확인: 원문 확인
