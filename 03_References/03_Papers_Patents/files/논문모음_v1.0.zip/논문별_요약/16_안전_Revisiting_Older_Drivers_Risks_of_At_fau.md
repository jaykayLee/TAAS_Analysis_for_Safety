# Revisiting Older Drivers' Risks of At-fault Motor Vehicle Collisions in Japan

- 주제: 안전
- 저자: Ichikawa M, Inada H, Nakahara S
- 학술지·발행: Journal of Epidemiology 34(6):295–300 doi:10.2188/jea.JE20230217 (2024)
- 자료·기간: 일본 경찰 보고 사고 2016~2020
- 방법: 면허 소지자당 가해 사고율, 사고당 피해자 수
- 핵심 결과: 고령 운전자 가해 사고율은 중년보다 높지만 청년보다는 낮음. 고령 가해 사망사고의 사망자는 주로 본인·동승자
- 이 프로젝트와의 연결: 분모 바꿔 보기(면허 소지자 6863), 노인운전자 장표
- 원문 공개: 공개(CC BY)
- 링크: https://www.jstage.jst.go.jp/article/jea/34/6/34_JE20230217/_article
- 공개 PDF: https://www.jstage.jst.go.jp/article/jea/34/6/34_JE20230217/_pdf
- 확인: 원문 확인
