# 고령운전자 연령구간별 사망사고 발생위험도와 사고비용 분석 연구 (Study on Fatality Risk of Older Driver and Traffic Accident Cost)

- 주제: 안전
- 저자: 최재성
- 학술지·발행: 한국안전학회지 33(4):111–118 (2018)
- 자료·기간: 도로교통공단 법규위반 사망 자료 2011~2015(약 8.9만 건)
- 방법: 로짓(최우추정)
- 핵심 결과: 65세 이상 운전자 관련 사망 586→776명(+32.5%), 80세 이상에서 차로위반 사망 오즈 약 2.24배
- 이 프로젝트와의 연결: 7266 노인운전자·7052 법규위반 — 연령 구간 세분화 근거
- 원문 공개: 공개(KoreaScience)
- 링크: https://koreascience.kr/article/JAKO201829562508985.pdf
- 공개 PDF: https://koreascience.kr/article/JAKO201829562508985.pdf
- 확인: 원문 확인
