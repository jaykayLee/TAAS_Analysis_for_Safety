# Global impact of COVID-19 pandemic on road traffic collisions

- 주제: 교통
- 저자: Yasin YJ, Grivna M, Abu-Zidan FM
- 학술지·발행: World Journal of Emergency Surgery 16:51 doi:10.1186/s13017-021-00395-8 (2021)
- 자료·기간: 2021-06까지 문헌·보고
- 방법: 서술적 문헌고찰
- 핵심 결과: 2020-04 도로 사망 36개국 중 32개국 감소, 연간 42개국 중 33개국 감소. 건수는 줄고 심각도는 증가(과속·빈 도로)
- 이 프로젝트와의 연결: 외부 충격(2020) 더미, 사망/사고 비
- 원문 공개: 공개(CC BY)
- 링크: https://pmc.ncbi.nlm.nih.gov/articles/PMC8478263
- 공개 PDF: https://pmc.ncbi.nlm.nih.gov/articles/PMC8478263/pdf/13017_2021_Article_395.pdf
- 확인: 원문 확인
