# Examining Road Traffic Mortality Status in China: A Simulation Study

- 주제: 사망률
- 저자: Huang H, Yin Q, Schwebel DC, et al.
- 학술지·발행: PLoS ONE 11(4):e0153251 doi:10.1371/journal.pone.0153251 (2016)
- 자료·기간: 중국 경찰 1970~2013·보건 2002~2013, OECD 13개국
- 방법: 수정 Smeed 식
- 핵심 결과: 경찰 자료는 2002 정점, 보건 자료는 2012 정점 — 경찰 자료 과소보고 가능성
- 이 프로젝트와의 연결: 분모 바꿔 보기·삼각검증 기법
- 원문 공개: 공개(CC BY)
- 링크: https://pmc.ncbi.nlm.nih.gov/articles/PMC4829231
- 공개 PDF: https://pmc.ncbi.nlm.nih.gov/articles/PMC4829231/pdf/pone.0153251.pdf
- 확인: 원문 확인
