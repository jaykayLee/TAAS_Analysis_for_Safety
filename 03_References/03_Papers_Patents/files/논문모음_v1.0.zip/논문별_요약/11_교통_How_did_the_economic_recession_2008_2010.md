# How did the economic recession (2008-2010) influence traffic fatalities in OECD-countries?

- 주제: 교통
- 저자: Wegman F, Allsop R, Antoniou C, et al.
- 학술지·발행: ITF/IRTAD 보고 기반 논문(수락 원고) (2017)
- 자료·기간: 유럽 30개국 1975~2011 등 3개 분석 + 41개 선행연구
- 방법: 음이항·상태공간·메타분석
- 핵심 결과: 모든 국가에서 불황기 사망 감소가 추세보다 빠름. 감소의 큰 몫은 주행량 감소보다 km당 사망률 하락
- 이 프로젝트와의 연결: 경기 변수(실업률) 라이브러리 근거, 2008·2020 해석
- 원문 공개: 공개(UCL 수락 원고)
- 링크: https://discovery-pp.ucl.ac.uk/10124562/1/Allsop_accepted%20manuscript%20of%20Wegman%20Allsop%20et%20al%202017.pdf
- 공개 PDF: https://discovery-pp.ucl.ac.uk/10124562/1/Allsop_accepted%20manuscript%20of%20Wegman%20Allsop%20et%20al%202017.pdf
- 확인: 원문 확인
